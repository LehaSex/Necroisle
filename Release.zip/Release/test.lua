local text = "Hello World"
local textMeshObject = CS.UnityEngine.GameObject("TextMeshProObject")

function start()
    print("lua start...")
    print("injected object", GameSingleton)
    -- Найти компонент класса GameSingleton 
    GameSingletonComponent = GameSingleton:GetComponent(typeof(CS.Necroisle.GameSingleton))
    print("GameSingletonComponent", GameSingletonComponent)
	print(GameSingletonComponent.resolutionInfo.width)
	CS.UnityEngine.Object.DontDestroyOnLoad(textMeshObject)
    -- Создание текстового объекта TextMeshPro
    textMeshPro = textMeshObject:AddComponent(typeof(CS.TMPro.TextMeshPro))
	
    -- Установка текста
    textMeshPro.text = text
    
    -- Установка выравнивания текста в центре
    textMeshPro.alignment = CS.TMPro.TextAlignmentOptions.Center
    
    -- Установка позиции текста в центре экрана
    textMeshPro.rectTransform.position = CS.UnityEngine.Vector3(GameSingletonComponent.resolutionInfo.width / 2, GameSingletonComponent.resolutionInfo.height / 2, 0)
	local pos = CS.UnityEngine.GameObject.Find("UI").transform
	textMeshPro.transform.position = pos
	
	-- Настройка градиента текста
	textMeshPro.enableVertexGradient = true
    local gradient = CS.TMPro.VertexGradient(CS.UnityEngine.Color.red, CS.UnityEngine.Color.blue, CS.UnityEngine.Color.green, CS.UnityEngine.Color.yellow)
    textMeshPro.colorGradient = gradient
end

function update()

    -- Меняем цвет текста градиентом в зависимости от времени
    local time = CS.UnityEngine.Time.time
    local color1 = CS.UnityEngine.Color.Lerp(CS.UnityEngine.Color.red, CS.UnityEngine.Color.blue, math.sin(time))
    local color2 = CS.UnityEngine.Color.Lerp(CS.UnityEngine.Color.green, CS.UnityEngine.Color.yellow, math.cos(time))
    local gradient = CS.TMPro.VertexGradient(color1, color2, color1, color2)
    textMeshPro.colorGradient = gradient
	
    GameSingletonComponent:CallDebugLog(text)
    local pos = GameSingleton.transform
    pos.position = pos.position + CS.UnityEngine.Vector3(0, 1, 0)
    print("lexa")
end

function ondestroy()
    print("lua destroy")
	CS.UnityEngine.Object.Destroy(textMeshObject)
end
