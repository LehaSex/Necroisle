var class_necroisle_1_1_action_pet_tame =
[
    [ "CanDoAction", "class_necroisle_1_1_action_pet_tame.html#a78c577e32cdb757ac142e8f335cb417d", null ],
    [ "DoAction", "class_necroisle_1_1_action_pet_tame.html#a96befea28f437cf2eab3755e53b61f94", null ]
];