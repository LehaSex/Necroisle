var class_necroisle_1_1_action_open =
[
    [ "CanDoAction", "class_necroisle_1_1_action_open.html#adddf2f94a8e5b06e11482da614b6a654", null ],
    [ "DoAction", "class_necroisle_1_1_action_open.html#a2d66577aa6cec3b140b39444b1fbac49", null ],
    [ "items", "class_necroisle_1_1_action_open.html#a4a26a737fdffc5b67a2439a306fb354c", null ]
];