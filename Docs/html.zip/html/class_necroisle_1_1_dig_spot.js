var class_necroisle_1_1_dig_spot =
[
    [ "Dig", "class_necroisle_1_1_dig_spot.html#a2c10e0bcb946a62629b72e7b26207b12", null ],
    [ "GetAll", "class_necroisle_1_1_dig_spot.html#ae96493b8ed31fa68e370cc331b135d3f", null ],
    [ "GetNearest", "class_necroisle_1_1_dig_spot.html#a530d5facd9753354847689d2cf1b2b87", null ]
];