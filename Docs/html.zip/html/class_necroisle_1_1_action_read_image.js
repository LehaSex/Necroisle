var class_necroisle_1_1_action_read_image =
[
    [ "CanDoAction", "class_necroisle_1_1_action_read_image.html#ab50f0946dabca918c663ef5a8da4b5ab", null ],
    [ "DoAction", "class_necroisle_1_1_action_read_image.html#a6e4cc3dfd47b0669d017279733e5861a", null ],
    [ "image", "class_necroisle_1_1_action_read_image.html#a2795ad40076c05e2c030d6e7e80c0a1e", null ]
];