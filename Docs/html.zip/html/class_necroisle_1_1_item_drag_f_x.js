var class_necroisle_1_1_item_drag_f_x =
[
    [ "Get", "class_necroisle_1_1_item_drag_f_x.html#a023cd48a1b79dbbd3308e9df52081e66", null ],
    [ "icon", "class_necroisle_1_1_item_drag_f_x.html#a3317e48e71d37fadaf58aee80ee32620", null ],
    [ "icon_group", "class_necroisle_1_1_item_drag_f_x.html#a12ddf3ddae67dd5a1088968c667bec7a", null ],
    [ "refresh_rate", "class_necroisle_1_1_item_drag_f_x.html#a448bb8c579161f0398b1661da13032dc", null ],
    [ "title", "class_necroisle_1_1_item_drag_f_x.html#aca67cabbe92d3f1a34a6431ca86e3d42", null ]
];