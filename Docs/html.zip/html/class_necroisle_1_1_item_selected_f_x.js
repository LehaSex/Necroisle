var class_necroisle_1_1_item_selected_f_x =
[
    [ "Get", "class_necroisle_1_1_item_selected_f_x.html#a5d0937751f90870a864a0405aeb5a71c", null ],
    [ "icon", "class_necroisle_1_1_item_selected_f_x.html#a9a0785f462cedcb3e8822c2a6230a4cb", null ],
    [ "icon_group", "class_necroisle_1_1_item_selected_f_x.html#a5a787b5e4ea7b0e9a480ce6b51201f9e", null ],
    [ "refresh_rate", "class_necroisle_1_1_item_selected_f_x.html#a4fa4fb7fbd50fa2053c439574e4cb1c1", null ],
    [ "title", "class_necroisle_1_1_item_selected_f_x.html#a095f2059a8d04a06a97ec7aa1671cbe9", null ]
];