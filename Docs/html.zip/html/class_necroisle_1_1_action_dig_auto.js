var class_necroisle_1_1_action_dig_auto =
[
    [ "CanDoAction", "class_necroisle_1_1_action_dig_auto.html#a78fa99c58a9de55704e3cf6dad308ca4", null ],
    [ "DoAction", "class_necroisle_1_1_action_dig_auto.html#a774e0eb15e68003a393af1515ca29f4d", null ],
    [ "required_item", "class_necroisle_1_1_action_dig_auto.html#a74333463a392a1f71b2d25e56f656daf", null ]
];