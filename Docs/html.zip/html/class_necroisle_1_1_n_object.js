var class_necroisle_1_1_n_object =
[
    [ "CountSceneObjects", "class_necroisle_1_1_n_object.html#acbe115927ee8a2442f094bc2ffefd523", null ],
    [ "CountSceneObjects", "class_necroisle_1_1_n_object.html#a578c2d12e6d606ddf73c2a992938cc27", null ],
    [ "Create", "class_necroisle_1_1_n_object.html#ad257c8fd25e294c46a94a54d1ad0c8c4", null ],
    [ "GetData", "class_necroisle_1_1_n_object.html#ad80fae31cd75d44df3f7e6c295593a1b", null ]
];