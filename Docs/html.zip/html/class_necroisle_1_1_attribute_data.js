var class_necroisle_1_1_attribute_data =
[
    [ "deplete_attack_mult", "class_necroisle_1_1_attribute_data.html#ab1ea4d37aa6a821963801ed2c659c2a3", null ],
    [ "deplete_hp_loss", "class_necroisle_1_1_attribute_data.html#a1585baff393093ecc73dfa0635e79af8", null ],
    [ "deplete_move_mult", "class_necroisle_1_1_attribute_data.html#ada712e6079dcd7ce8e7e3b02d0433c8d", null ],
    [ "max_value", "class_necroisle_1_1_attribute_data.html#a41c4d91092611343a7b671fd8dc3b130", null ],
    [ "start_value", "class_necroisle_1_1_attribute_data.html#afa30a543823fa985fe6d35320d73bec0", null ],
    [ "title", "class_necroisle_1_1_attribute_data.html#a8c978a9c58ea987771a424c20dbf0ce2", null ],
    [ "type", "class_necroisle_1_1_attribute_data.html#a901218061c97d9623c56b0e0d758c9ee", null ],
    [ "value_per_hour", "class_necroisle_1_1_attribute_data.html#a855fbd89c0bac140ac215c6105e851ae", null ]
];