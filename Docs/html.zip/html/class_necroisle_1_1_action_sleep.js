var class_necroisle_1_1_action_sleep =
[
    [ "DoAction", "class_necroisle_1_1_action_sleep.html#ab2883f7b803c355aaafb502e7c1f8820", null ],
    [ "sleep_hapiness_hour", "class_necroisle_1_1_action_sleep.html#a3c486067ac3ceade7cc976305403bdf5", null ],
    [ "sleep_hp_hour", "class_necroisle_1_1_action_sleep.html#a5bab4c1a992870ae662600173aa9d855", null ],
    [ "sleep_hunger_hour", "class_necroisle_1_1_action_sleep.html#af10d0cedaa60975148b1dfdce716a4ba", null ],
    [ "sleep_speed_mult", "class_necroisle_1_1_action_sleep.html#af6864f800f22496d7fffccff8f6bd181", null ],
    [ "sleep_thirst_hour", "class_necroisle_1_1_action_sleep.html#a8fa26e6ab15ee1746b74e16530f3a2c6", null ]
];