var class_necroisle_1_1_action_set_trap =
[
    [ "CanDoAction", "class_necroisle_1_1_action_set_trap.html#ab817066357c9e2ef931ae90c96f11dd9", null ],
    [ "DoAction", "class_necroisle_1_1_action_set_trap.html#a05afeae0c6d952443957394169be588b", null ]
];