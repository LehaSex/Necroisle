var class_necroisle_1_1_loot_data =
[
    [ "item", "class_necroisle_1_1_loot_data.html#a5e5c4bf525c889e6877b7e36f56d83ea", null ],
    [ "probability", "class_necroisle_1_1_loot_data.html#a92b167dbf0a99d1730b1e2d95760e724", null ],
    [ "quantity", "class_necroisle_1_1_loot_data.html#a58dc99be76ede43e9399e9c04c0c5505", null ]
];