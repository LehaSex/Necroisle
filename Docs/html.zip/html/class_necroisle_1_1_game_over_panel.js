var class_necroisle_1_1_game_over_panel =
[
    [ "Awake", "class_necroisle_1_1_game_over_panel.html#a255f062911ad3b4e841a9396da481c84", null ],
    [ "Get", "class_necroisle_1_1_game_over_panel.html#acfcf61d65ee1600d161333ce99e24db3", null ],
    [ "OnClickLoad", "class_necroisle_1_1_game_over_panel.html#a6a4e60b0d0c49b63b42e36ac1f384914", null ],
    [ "OnClickNew", "class_necroisle_1_1_game_over_panel.html#a63c5fc9b249be01bd3bb30505f300a16", null ],
    [ "Start", "class_necroisle_1_1_game_over_panel.html#a17aa94f50427071181b5d44eb0ebbda0", null ],
    [ "Update", "class_necroisle_1_1_game_over_panel.html#a85d7096f34249446381260db1fec494d", null ]
];