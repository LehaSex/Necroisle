var class_necroisle_1_1_action_plant =
[
    [ "CanDoAction", "class_necroisle_1_1_action_plant.html#a28894fc045b8ef1d504de3346c9f5b1f", null ],
    [ "DoAction", "class_necroisle_1_1_action_plant.html#acd8aa0f56c2dcb299d529e96bd53e21f", null ]
];