var class_necroisle_1_1_main_menu_manager =
[
    [ "ScreenType", "class_necroisle_1_1_main_menu_manager.html#a309f4d901d344aea8cb54b48119e35d6", [
      [ "Play", "class_necroisle_1_1_main_menu_manager.html#a309f4d901d344aea8cb54b48119e35d6ade3c731be5633838089a07179d301d7b", null ],
      [ "Characters", "class_necroisle_1_1_main_menu_manager.html#a309f4d901d344aea8cb54b48119e35d6a994d06622c761cbceb384fd10a0b53f3", null ],
      [ "Settings", "class_necroisle_1_1_main_menu_manager.html#a309f4d901d344aea8cb54b48119e35d6af4f70727dc34561dfde1a3c529b6205c", null ],
      [ "Menu", "class_necroisle_1_1_main_menu_manager.html#a309f4d901d344aea8cb54b48119e35d6ab61541208db7fa7dba42c85224405911", null ],
      [ "Lua", "class_necroisle_1_1_main_menu_manager.html#a309f4d901d344aea8cb54b48119e35d6a0ae9478a1db9d1e2c48efa49eac1c7c6", null ]
    ] ],
    [ "BackFromCharacters", "class_necroisle_1_1_main_menu_manager.html#aad7d8ea8f8279c8d9d8881088b02cfa7", null ],
    [ "BackFromLuaButton", "class_necroisle_1_1_main_menu_manager.html#a5bfc91115fabaa1781e14b686b2d182d", null ],
    [ "BackFromSettingsButton", "class_necroisle_1_1_main_menu_manager.html#a21d8a20048c74e6d1233570c655af696", null ],
    [ "CharactersButton", "class_necroisle_1_1_main_menu_manager.html#aee43593eb8c2b056c52d1ca97ad5c621", null ],
    [ "CharactersPanel", "class_necroisle_1_1_main_menu_manager.html#ad93fe96268f0527c4f3decb356b59747", null ],
    [ "CurrentPanel", "class_necroisle_1_1_main_menu_manager.html#af3aafc4edeb316bfe4976fb63c74ae5c", null ],
    [ "ExitButton", "class_necroisle_1_1_main_menu_manager.html#a4a6093e71f4f76f476404209f621eb61", null ],
    [ "Header", "class_necroisle_1_1_main_menu_manager.html#a804270c5c9f83eafd71128bee722cf31", null ],
    [ "LuaButton", "class_necroisle_1_1_main_menu_manager.html#af9465ba971cd5f26a4d365bf09763f1b", null ],
    [ "LuaPanel", "class_necroisle_1_1_main_menu_manager.html#adedf121b362305bc9b06085252e332e7", null ],
    [ "LuaRefreshButton", "class_necroisle_1_1_main_menu_manager.html#aa125a2a245f03c19d549efb404fc7536", null ],
    [ "MenuPanel", "class_necroisle_1_1_main_menu_manager.html#a949eff70dc173611f68dfc4b8a7d286c", null ],
    [ "PlayButton", "class_necroisle_1_1_main_menu_manager.html#a3e18f78b1ff691cd9dcbb87ed3eb7720", null ],
    [ "PlayPanel", "class_necroisle_1_1_main_menu_manager.html#adda3c87b9a2a95313dff173ca96ca27d", null ],
    [ "SettingsButton", "class_necroisle_1_1_main_menu_manager.html#a632c2cb2643af3dd4f4235f4403fea5f", null ],
    [ "SettingsPanel", "class_necroisle_1_1_main_menu_manager.html#a6eab857b9f8f5c74bd5289ea67d913dd", null ],
    [ "VKButton", "class_necroisle_1_1_main_menu_manager.html#a625b94f7485b4b63a5f73aa25c77dcc8", null ]
];