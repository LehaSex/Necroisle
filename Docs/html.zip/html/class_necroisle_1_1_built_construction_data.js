var class_necroisle_1_1_built_construction_data =
[
    [ "construction_id", "class_necroisle_1_1_built_construction_data.html#a7ab313436a89574e503147df3e240e25", null ],
    [ "durability", "class_necroisle_1_1_built_construction_data.html#a016aaac3b450b26164683e4cedb0ee94", null ],
    [ "pos", "class_necroisle_1_1_built_construction_data.html#aa183d55c111b23ed8a7f12a2f3e172a1", null ],
    [ "rot", "class_necroisle_1_1_built_construction_data.html#a6b50bc95f6877b0d27f7c2fe0259c55f", null ],
    [ "scene", "class_necroisle_1_1_built_construction_data.html#a679c5948a5f0aa326bf0a5be3eae8620", null ],
    [ "uid", "class_necroisle_1_1_built_construction_data.html#a722990eab5b131226c66157e9453a151", null ]
];