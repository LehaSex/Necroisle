var class_necroisle_1_1_action_drink_pond =
[
    [ "DoAction", "class_necroisle_1_1_action_drink_pond.html#ab7b6110712fd83456c3076d185e77903", null ],
    [ "drink_happiness", "class_necroisle_1_1_action_drink_pond.html#a4771cab992ebfbeea4a34698833f3bd6", null ],
    [ "drink_hp", "class_necroisle_1_1_action_drink_pond.html#afd3268c338d7838226af4cb7e9734cdf", null ],
    [ "drink_hunger", "class_necroisle_1_1_action_drink_pond.html#a091a0814c3f7951fb4f26f72f74a51d4", null ],
    [ "drink_thirst", "class_necroisle_1_1_action_drink_pond.html#abbe56c756c54c052d2beb389f8de4dd2", null ]
];