var class_necroisle_1_1_craft_cost_data =
[
    [ "craft_fillers", "class_necroisle_1_1_craft_cost_data.html#af1ea4926c57ad0f4d79c7b1871b3fc90", null ],
    [ "craft_items", "class_necroisle_1_1_craft_cost_data.html#af9a39fde087ab94bb86e7eab442b5891", null ],
    [ "craft_near", "class_necroisle_1_1_craft_cost_data.html#ab9b140311561a42a4bd6f3018fa4b0be", null ],
    [ "craft_requirements", "class_necroisle_1_1_craft_cost_data.html#a115c799218aeb6b6a93958292da643e5", null ]
];