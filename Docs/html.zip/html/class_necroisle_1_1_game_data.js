var class_necroisle_1_1_game_data =
[
    [ "Get", "class_necroisle_1_1_game_data.html#afb8d6e1be63d27078e7a94fae2b840fc", null ],
    [ "day_light_ambient_intensity", "class_necroisle_1_1_game_data.html#acbcd656a3e1abb6c0f322b9bab035642", null ],
    [ "day_light_dir_intensity", "class_necroisle_1_1_game_data.html#a7f9ff7e1e779d279189251913537c5b9", null ],
    [ "game_time_mult", "class_necroisle_1_1_game_data.html#a63521abbc12e4ebeed206244611df82d", null ],
    [ "music_playlist", "class_necroisle_1_1_game_data.html#a1de221c0a2cd1780d0e8717dcb9030bb", null ],
    [ "night_light_ambient_intensity", "class_necroisle_1_1_game_data.html#a61b70704d544ee67ded48102804437aa", null ],
    [ "night_light_dir_intensity", "class_necroisle_1_1_game_data.html#a7141595e8fef492d2063102089f1ac76", null ],
    [ "optim_distance_multiplier", "class_necroisle_1_1_game_data.html#ade3e6addae7efecbc621842fb38d8da9", null ],
    [ "optim_facing_offset", "class_necroisle_1_1_game_data.html#a9e02ce8816fb23347ee182310f48aa6d", null ],
    [ "optim_refresh_rate", "class_necroisle_1_1_game_data.html#aa445d99b3d337336661808b420590889", null ],
    [ "optim_turn_off_gameobjects", "class_necroisle_1_1_game_data.html#ad591c65bb7202d96cdfac06d7bd4d8d5", null ],
    [ "rotate_shadows", "class_necroisle_1_1_game_data.html#ac53fcf6b46b5be0581e6c08d97ec60d8", null ]
];