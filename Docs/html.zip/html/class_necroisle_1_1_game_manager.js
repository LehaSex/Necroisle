var class_necroisle_1_1_game_manager =
[
    [ "getChunkSize", "class_necroisle_1_1_game_manager.html#ad8e1d961572fec09bbaca3d050843e65", null ],
    [ "setChunkSize", "class_necroisle_1_1_game_manager.html#a6d68794bc4f72a6117fda38ef33ae644", null ],
    [ "Instance", "class_necroisle_1_1_game_manager.html#a5757cbf675166e05c6468277353d17b9", null ]
];