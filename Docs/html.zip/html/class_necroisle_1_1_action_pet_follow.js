var class_necroisle_1_1_action_pet_follow =
[
    [ "CanDoAction", "class_necroisle_1_1_action_pet_follow.html#ae4e39d90970ba1b37fe8c8ca5d5c7632", null ],
    [ "DoAction", "class_necroisle_1_1_action_pet_follow.html#a52d7ffc840065da3f02d23fd605f8d34", null ]
];