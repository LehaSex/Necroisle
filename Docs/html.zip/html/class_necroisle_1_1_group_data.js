var class_necroisle_1_1_group_data =
[
    [ "group_id", "class_necroisle_1_1_group_data.html#aadb2452df93b1f08bb4279322ed7b59c", null ],
    [ "icon", "class_necroisle_1_1_group_data.html#a706521de432f29427bfd7c6e159ab1c4", null ],
    [ "title", "class_necroisle_1_1_group_data.html#af2d01192a22f59578aadf6aeb4ee51aa", null ]
];