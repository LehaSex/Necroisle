var class_necroisle_1_1_chest_anim =
[
    [ "chest_lid", "class_necroisle_1_1_chest_anim.html#ad9296df2cc1b9aded0d96633a09ca6ca", null ],
    [ "chest_lid_outline", "class_necroisle_1_1_chest_anim.html#acc1c807c9583c3adae35f6d6dd2dd5a5", null ]
];