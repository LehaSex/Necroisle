var class_necroisle_1_1_material_tool =
[
    [ "ChangeRenderMode", "class_necroisle_1_1_material_tool.html#a1e33cdc05ec06e947ead83f9aae6fba5", null ],
    [ "HasColor", "class_necroisle_1_1_material_tool.html#ab2ade5820413c6c32bfefd853c41fd6f", null ],
    [ "IsStandard", "class_necroisle_1_1_material_tool.html#ab9281207cfae3e62bbd412502dfac3e8", null ]
];