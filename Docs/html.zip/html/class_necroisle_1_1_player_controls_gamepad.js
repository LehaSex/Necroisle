var class_necroisle_1_1_player_controls_gamepad =
[
    [ "player_id", "class_necroisle_1_1_player_controls_gamepad.html#abd2cc183d8a683741205c28fc83c39d3", null ]
];