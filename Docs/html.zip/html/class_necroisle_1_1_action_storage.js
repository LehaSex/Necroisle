var class_necroisle_1_1_action_storage =
[
    [ "CanDoAction", "class_necroisle_1_1_action_storage.html#a2c52bd26e6bc5df58dec972c7d58f1a3", null ],
    [ "DoAction", "class_necroisle_1_1_action_storage.html#ac1296fc18e17f05d97770919c36b799f", null ]
];