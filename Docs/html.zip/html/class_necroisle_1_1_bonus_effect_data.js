var class_necroisle_1_1_bonus_effect_data =
[
    [ "GetAttributeBonusType", "class_necroisle_1_1_bonus_effect_data.html#adc631e574b87ba1de6b33b48b80e308e", null ],
    [ "GetAttributeMaxBonusType", "class_necroisle_1_1_bonus_effect_data.html#a5861fd2b6794c24fb02b518031b1a9fd", null ],
    [ "effect_id", "class_necroisle_1_1_bonus_effect_data.html#a1fbdeb52a69b31e08b7b294c05e9b13f", null ],
    [ "target", "class_necroisle_1_1_bonus_effect_data.html#a825a4da5a14cb0ee1f45da7ad1ec8074", null ],
    [ "type", "class_necroisle_1_1_bonus_effect_data.html#ac4b54295277381b3b371e1c0f6c8f85f", null ],
    [ "value", "class_necroisle_1_1_bonus_effect_data.html#a9c39b6f90a514d194ac4a3451e1686d9", null ]
];