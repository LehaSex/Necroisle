var class_necroisle_1_1_action_equip =
[
    [ "CanDoAction", "class_necroisle_1_1_action_equip.html#a942eedaa9d1eae922cfdea4437fd95b9", null ],
    [ "DoAction", "class_necroisle_1_1_action_equip.html#ab393b595ed95257868a7dab3cb465824", null ]
];