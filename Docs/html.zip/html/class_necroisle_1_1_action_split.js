var class_necroisle_1_1_action_split =
[
    [ "CanDoAction", "class_necroisle_1_1_action_split.html#a5b6eff311ea701d5656cd45bf6c5c95a", null ],
    [ "DoAction", "class_necroisle_1_1_action_split.html#a6211dddda7c74c844d76d319a3e62085", null ]
];