var class_necroisle_1_1_item_merge_f_x =
[
    [ "icon", "class_necroisle_1_1_item_merge_f_x.html#aef5b5086ccabe77352a870b0ba78e627", null ],
    [ "icon_group", "class_necroisle_1_1_item_merge_f_x.html#ab7451381010f1dec901aa07a4ec567cb", null ],
    [ "target", "class_necroisle_1_1_item_merge_f_x.html#a30eb2642fa82ee1d20b7e4d5993a112a", null ],
    [ "title", "class_necroisle_1_1_item_merge_f_x.html#a4dca48beecc42100852a43c8d1cb039e", null ]
];