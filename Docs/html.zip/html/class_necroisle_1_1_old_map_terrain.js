var class_necroisle_1_1_old_map_terrain =
[
    [ "player", "class_necroisle_1_1_old_map_terrain.html#a560b32f4a084cf685d39d55ba70076e4", null ]
];