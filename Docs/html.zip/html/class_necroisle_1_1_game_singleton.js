var class_necroisle_1_1_game_singleton =
[
    [ "CallDebugLog", "class_necroisle_1_1_game_singleton.html#a561418f31d74e3c5dad5b19d1af3648d", null ],
    [ "IsPC", "class_necroisle_1_1_game_singleton.html#a35a63dc2c3ec2a9524aa5574089f8a65", null ]
];