var class_necroisle_1_1_player_pet_data =
[
    [ "pet_id", "class_necroisle_1_1_player_pet_data.html#a7bbc88f4574d2bacc5f871d8b335b2b9", null ],
    [ "uid", "class_necroisle_1_1_player_pet_data.html#aeaf1aef158ac4137746d1fecc3d63b36", null ]
];