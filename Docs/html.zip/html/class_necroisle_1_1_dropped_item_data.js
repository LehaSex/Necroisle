var class_necroisle_1_1_dropped_item_data =
[
    [ "durability", "class_necroisle_1_1_dropped_item_data.html#a388d4430ad0b900d7f530da479355be3", null ],
    [ "item_id", "class_necroisle_1_1_dropped_item_data.html#ac7b8c6b3167602e70601c1a2b44ecc0f", null ],
    [ "pos", "class_necroisle_1_1_dropped_item_data.html#abbc0406fc51009c35a3ba2e84bfcdb59", null ],
    [ "quantity", "class_necroisle_1_1_dropped_item_data.html#aea989fca3075b9d702d7e8b4e201909e", null ],
    [ "scene", "class_necroisle_1_1_dropped_item_data.html#ad2a0a83ccafa0175642b4fbc187e3f2f", null ],
    [ "uid", "class_necroisle_1_1_dropped_item_data.html#a8f7862717333ef76cc729ef85f206293", null ]
];