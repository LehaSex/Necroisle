var class_necroisle_1_1_action_read =
[
    [ "CanDoAction", "class_necroisle_1_1_action_read.html#aa4d7fabef20468ac5851434f8da50c14", null ],
    [ "DoAction", "class_necroisle_1_1_action_read.html#a19c7c5af2e1f803dcf61c1f4b7d04367", null ]
];