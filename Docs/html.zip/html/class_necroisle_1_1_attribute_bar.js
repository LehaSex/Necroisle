var class_necroisle_1_1_attribute_bar =
[
    [ "attribute", "class_necroisle_1_1_attribute_bar.html#a43bf2e731d16d9e949d4d1d21a320c82", null ]
];