var class_necroisle_1_1_action_dig =
[
    [ "CanDoAction", "class_necroisle_1_1_action_dig.html#a4e36e76fd920ee6cfe78578de92e17a1", null ],
    [ "DoAction", "class_necroisle_1_1_action_dig.html#acfa38c990edf106c575f41cba7965223", null ],
    [ "dig_range", "class_necroisle_1_1_action_dig.html#a3c11f3de1c28cffb0b50244168ef486a", null ]
];