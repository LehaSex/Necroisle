var class_necroisle_1_1_level_data =
[
    [ "GetLevel", "class_necroisle_1_1_level_data.html#a482c67ea52eeaff85e3529ac456ef3ef", null ],
    [ "GetLevelByXP", "class_necroisle_1_1_level_data.html#aaf5e7dcf43420bebfc4a310fd48b060b", null ],
    [ "GetMaxLevel", "class_necroisle_1_1_level_data.html#abb87d14ba25e40710c053352470c7329", null ],
    [ "Load", "class_necroisle_1_1_level_data.html#aea2f2ca4fb15342456f715f79c0dadfe", null ],
    [ "id", "class_necroisle_1_1_level_data.html#a71f2fb97ba0018122dbbe9bfc7fdf66f", null ],
    [ "level", "class_necroisle_1_1_level_data.html#a9c7fce8287e607a859b419b988a766ff", null ],
    [ "unlock_bonuses", "class_necroisle_1_1_level_data.html#a3d66db3b9e08359aa2f115ebdc74a0c7", null ],
    [ "unlock_craft", "class_necroisle_1_1_level_data.html#a6fe83cb6d0439f5d7cd13db7163e3f41", null ],
    [ "xp_required", "class_necroisle_1_1_level_data.html#a9b1e641e3ffb22d3d32bef07dc854d8c", null ]
];