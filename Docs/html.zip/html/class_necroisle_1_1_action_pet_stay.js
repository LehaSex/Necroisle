var class_necroisle_1_1_action_pet_stay =
[
    [ "CanDoAction", "class_necroisle_1_1_action_pet_stay.html#ae2e38677562164ca2ec5775a15f9d01d", null ],
    [ "DoAction", "class_necroisle_1_1_action_pet_stay.html#ae171f5aca1a29da32b95546f7a493d77", null ]
];