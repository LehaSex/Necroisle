var class_necroisle_1_1_action_destroy =
[
    [ "CanDoAction", "class_necroisle_1_1_action_destroy.html#a958ddf422124fc8f71abe00974efc90e", null ],
    [ "DoAction", "class_necroisle_1_1_action_destroy.html#a6c25132f348d873dc9dbf74e9cc14b29", null ],
    [ "animation", "class_necroisle_1_1_action_destroy.html#ab382a1185016a540f3833c63c3cd9913", null ]
];