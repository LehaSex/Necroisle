var class_necroisle_1_1_player_level_data =
[
    [ "id", "class_necroisle_1_1_player_level_data.html#a9d19ba31a8f18556e32b552c6a77e6dc", null ],
    [ "level", "class_necroisle_1_1_player_level_data.html#a0357264c637282758a3dbab6812a4dee", null ],
    [ "xp", "class_necroisle_1_1_player_level_data.html#ab0c442eb2503fbf3e0c26c7e701709f1", null ]
];