var class_necroisle_1_1_injection =
[
    [ "name", "class_necroisle_1_1_injection.html#a1704e91656c0a9833c489200697f0168", null ],
    [ "value", "class_necroisle_1_1_injection.html#a85dc634e6d875c8c50a669ff4117fd9f", null ]
];