var class_necroisle_1_1_inventory_item_data =
[
    [ "InventoryItemData", "class_necroisle_1_1_inventory_item_data.html#aee4449764ada5c1bea92e6cef1382aba", null ],
    [ "GetItem", "class_necroisle_1_1_inventory_item_data.html#a606c1dd770c9e267cc96246b4683bcbf", null ],
    [ "durability", "class_necroisle_1_1_inventory_item_data.html#a744859563946a6d3f9f6daa5504a73d8", null ],
    [ "item_id", "class_necroisle_1_1_inventory_item_data.html#a44e77b9a7dbdea3bf13ffc75b5dcec1a", null ],
    [ "quantity", "class_necroisle_1_1_inventory_item_data.html#a7e3c80167da4aa47d34f9db3e5bb17c4", null ],
    [ "uid", "class_necroisle_1_1_inventory_item_data.html#a123015f4c8aa057017ed133d678e8216", null ]
];