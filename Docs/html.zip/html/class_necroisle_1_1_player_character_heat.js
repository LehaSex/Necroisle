var class_necroisle_1_1_player_character_heat =
[
    [ "Get", "class_necroisle_1_1_player_character_heat.html#abaf2c290b115d682d36b0b11f67b82f3", null ],
    [ "GetAll", "class_necroisle_1_1_player_character_heat.html#af3651bd20d34a5668b7ba6fff89c6856", null ],
    [ "IsCold", "class_necroisle_1_1_player_character_heat.html#af609ce5033100cb50aa6e11b79c59afc", null ],
    [ "IsColdDamage", "class_necroisle_1_1_player_character_heat.html#aacc4e002f5e8e31d7f99a1e0f32f243a", null ],
    [ "SetGlobalHeat", "class_necroisle_1_1_player_character_heat.html#acb78f4f332e0deafa27889f1e9458e0c", null ],
    [ "cold_resist", "class_necroisle_1_1_player_character_heat.html#ad7151e210dbfcba8069cc9165182d653", null ],
    [ "cold_threshold", "class_necroisle_1_1_player_character_heat.html#abd7637e35cd0645451e89698176bf62e", null ],
    [ "damage_hp_loss", "class_necroisle_1_1_player_character_heat.html#ab3f6c51da3d030db3e26a1c0326ff1b0", null ],
    [ "damage_threshold", "class_necroisle_1_1_player_character_heat.html#ad3556b30b672495f23f747e669c758a5", null ],
    [ "global_heat", "class_necroisle_1_1_player_character_heat.html#ac8db885496c5d46b6f3ecc9e56609e27", null ],
    [ "global_heat_weight", "class_necroisle_1_1_player_character_heat.html#a1f71c83ba0447813375c78cc7cf4250c", null ],
    [ "heat_change_speed", "class_necroisle_1_1_player_character_heat.html#a362809881cbe332d600bf72e25e0fc9c", null ]
];