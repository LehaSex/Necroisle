var class_necroisle_1_1_mod_injector =
[
    [ "injections", "class_necroisle_1_1_mod_injector.html#a49f7b3a67a868be10c0efcca8c03fcb4", null ],
    [ "luaScript", "class_necroisle_1_1_mod_injector.html#a43985ecbe45c0595e4134b8a7f6c7dc2", null ],
    [ "Instance", "class_necroisle_1_1_mod_injector.html#acaa93217737a6169192fc208572a46f3", null ]
];