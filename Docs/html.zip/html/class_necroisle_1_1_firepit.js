var class_necroisle_1_1_firepit =
[
    [ "AddFuel", "class_necroisle_1_1_firepit.html#acb2442d5dcad852a3c3ff8ef24cdc1d4", null ],
    [ "GetAll", "class_necroisle_1_1_firepit.html#ad91c66c78de2f97e218de4bf617e3247", null ],
    [ "GetFireUID", "class_necroisle_1_1_firepit.html#a47fe51cd792297f555f0c17ba67d9afa", null ],
    [ "GetNearest", "class_necroisle_1_1_firepit.html#a33d3ce427f0832a38573438de7eae544", null ],
    [ "IsOn", "class_necroisle_1_1_firepit.html#adbe495b9038f84eff9eb117cd5aa9db1", null ],
    [ "fire_fx", "class_necroisle_1_1_firepit.html#ad91b7d5f589a5879a126e190eeb33a38", null ],
    [ "fire_group", "class_necroisle_1_1_firepit.html#adc4dd8e1b58168e5da8412211710218d", null ],
    [ "fuel_model", "class_necroisle_1_1_firepit.html#abb3b48dc9cdb829ab4649b361f0553e8", null ],
    [ "fuel_per_hour", "class_necroisle_1_1_firepit.html#a0b2cd10381c1677ef63726aacbde0764", null ],
    [ "max_fuel", "class_necroisle_1_1_firepit.html#a7c2537bb5938eb1e8ddd77f8cac654c1", null ],
    [ "start_fuel", "class_necroisle_1_1_firepit.html#a7b89a0abfe7bdc1b265959e297ae51e1", null ],
    [ "wood_add_fuel", "class_necroisle_1_1_firepit.html#af90051df75be1fba9312c4511b936e08", null ]
];