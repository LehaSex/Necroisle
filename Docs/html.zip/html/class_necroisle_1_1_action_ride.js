var class_necroisle_1_1_action_ride =
[
    [ "CanDoAction", "class_necroisle_1_1_action_ride.html#a867dce20b3f652bf5b096d11be2ccd12", null ],
    [ "DoAction", "class_necroisle_1_1_action_ride.html#add56df5b65931f3bc36b82665515bfb8", null ]
];