var class_necroisle_1_1_level_unlock_bonus =
[
    [ "bonus", "class_necroisle_1_1_level_unlock_bonus.html#ad1f76fe70f0ca33385c0f8b6e533df43", null ],
    [ "bonus_value", "class_necroisle_1_1_level_unlock_bonus.html#ad1cd9710df08868881e9a2b373bb15bd", null ],
    [ "target_group", "class_necroisle_1_1_level_unlock_bonus.html#a1c15895f89e9a6dd9156687afe2a1775", null ]
];