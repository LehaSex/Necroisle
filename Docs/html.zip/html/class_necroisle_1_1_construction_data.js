var class_necroisle_1_1_construction_data =
[
    [ "Get", "class_necroisle_1_1_construction_data.html#a05c3b0093220e53ae435bcb204048c5b", null ],
    [ "GetAll", "class_necroisle_1_1_construction_data.html#a33cdbe214362a1dbc36bd015549335af", null ],
    [ "HasDurability", "class_necroisle_1_1_construction_data.html#a0c26becc87e49f7935bd7a3e94af7405", null ],
    [ "Load", "class_necroisle_1_1_construction_data.html#a861ab31f29c83c555dae13ac2b863acb", null ],
    [ "construction_prefab", "class_necroisle_1_1_construction_data.html#af004ac47fdd212c61ff90f505535e01a", null ],
    [ "durability", "class_necroisle_1_1_construction_data.html#a60c4aaae67caabb88ea5333e72c65f22", null ],
    [ "durability_type", "class_necroisle_1_1_construction_data.html#a95c685cec972e14f7847fcd3e80484fa", null ],
    [ "take_item_data", "class_necroisle_1_1_construction_data.html#ac8b50e0621b921e5f495d1c4b5dd492a", null ]
];