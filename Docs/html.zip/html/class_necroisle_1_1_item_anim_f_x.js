var class_necroisle_1_1_item_anim_f_x =
[
    [ "anim", "class_necroisle_1_1_item_anim_f_x.html#a1298f790b746355baf78cb19eda39b94", null ],
    [ "fx", "class_necroisle_1_1_item_anim_f_x.html#acafadf68252fee71f0084f3f16090f70", null ]
];