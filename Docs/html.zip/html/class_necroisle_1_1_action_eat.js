var class_necroisle_1_1_action_eat =
[
    [ "CanDoAction", "class_necroisle_1_1_action_eat.html#a7646ffbfdc61719488286d664cef19b8", null ],
    [ "DoAction", "class_necroisle_1_1_action_eat.html#aa360eb520b7d204b3c14ff160257e5ba", null ]
];