var class_necroisle_1_1_projectile =
[
    [ "SetInitialCurve", "class_necroisle_1_1_projectile.html#ad9221bffc5018062b28408d6ba2e3a02", null ],
    [ "damage", "class_necroisle_1_1_projectile.html#a2bbbba3add5eadee68421de145f6273e", null ],
    [ "dir", "class_necroisle_1_1_projectile.html#a93b2dafeed3b2cbaf5fbb8b7cbcb2152", null ],
    [ "duration", "class_necroisle_1_1_projectile.html#a38460f97a7abdff0a1b8c53fd766e41d", null ],
    [ "gravity", "class_necroisle_1_1_projectile.html#a1bcca6c2d60bc92517935aa6ec8fff69", null ],
    [ "shoot_sound", "class_necroisle_1_1_projectile.html#a57e68dbb2edfbfec45f7d716bd583202", null ],
    [ "shooter", "class_necroisle_1_1_projectile.html#aea6eae99e1d2857463764a6b66d23c3f", null ],
    [ "speed", "class_necroisle_1_1_projectile.html#a92ba8155939bc109293a58b624119f50", null ]
];