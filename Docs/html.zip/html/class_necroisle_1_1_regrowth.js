var class_necroisle_1_1_regrowth =
[
    [ "CreateRegrowthData", "class_necroisle_1_1_regrowth.html#a10b4f3373bd2b6d56b25d1d6b6aa2d44", null ],
    [ "SpawnRegrowth", "class_necroisle_1_1_regrowth.html#a9aea847cf27a9acd8c7cd9214aa1581f", null ],
    [ "duration", "class_necroisle_1_1_regrowth.html#ab58bfffd5c4f857b93008f61c8ede27f", null ],
    [ "max", "class_necroisle_1_1_regrowth.html#af09835793734b9a5e4914a2501c4abbe", null ],
    [ "probability", "class_necroisle_1_1_regrowth.html#aa148f0956cf27bff5326dd07f037ce99", null ],
    [ "random_rotation", "class_necroisle_1_1_regrowth.html#a42656307e5df3dee139a3cac25d62601", null ],
    [ "random_scale", "class_necroisle_1_1_regrowth.html#af58ac221f518340ce6697ed286eb665c", null ],
    [ "range", "class_necroisle_1_1_regrowth.html#a4928570f29989f030cee7f61f9cddb77", null ],
    [ "spawn_data", "class_necroisle_1_1_regrowth.html#a088b5e448aba22273e74810994004019", null ],
    [ "type", "class_necroisle_1_1_regrowth.html#a0d2dd3e02a69550367bf155a48543c7f", null ],
    [ "valid_floor", "class_necroisle_1_1_regrowth.html#a526930712b9fb83e85d55ca7e0b9e369", null ]
];