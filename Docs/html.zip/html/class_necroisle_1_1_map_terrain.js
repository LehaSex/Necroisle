var class_necroisle_1_1_map_terrain =
[
    [ "player", "class_necroisle_1_1_map_terrain.html#ae218e9de278a5cf0e7dc77839cba913f", null ]
];