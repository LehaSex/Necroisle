var class_necroisle_1_1_bonus_aura =
[
    [ "GetAll", "class_necroisle_1_1_bonus_aura.html#a114b0e22915728eb7cebccb3dc59593c", null ],
    [ "effect", "class_necroisle_1_1_bonus_aura.html#ab38a5897b04ebd9270acafcc0b48577e", null ],
    [ "range", "class_necroisle_1_1_bonus_aura.html#a7b70da7f178a7b65b87fb4fc831fb36f", null ]
];